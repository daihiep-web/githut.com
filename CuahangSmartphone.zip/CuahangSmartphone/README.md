Thiết kế giao diện cho hoạt động đăng ký và đăng nhập
## LTDĐ - Nhóm 3
## Screenshots
<p>
  <img src="https://trello-attachments.s3.amazonaws.com/5ed622002651b51257a49f69/5ee8578d5ede34841dc2c4b5/f216394e4b5436ba0b817f67aa0a8fda/screenshot-2020-06-21_15.45.26.05.png" width="288" height="550" />
  <img src="https://trello-attachments.s3.amazonaws.com/5ed622002651b51257a49f69/5ee857967236a48cb4a65cfd/7d74a8924d07025f9368c07c4f50a534/screenshot-2020-06-21_15.45.34.621.png" width="288" height="550" /> </p>
## Giao diện trang chủ và thanh toán
<p>
<img src="https://trello-attachments.s3.amazonaws.com/5ed622002651b51257a49f69/5ee255aea17ece4504dc9c4b/65ed07043f2aa2c25d679871bcbcd0a5/screenshot-2020-06-26_00.55.44.326.png" width="288" height="550" /> 
<img src="https://trello-attachments.s3.amazonaws.com/5ed622002651b51257a49f69/5ee255aea17ece4504dc9c4b/8387306f79a1ccd2490c69fb5b36bab7/screenshot-2020-06-24_12.43.19.852.png" width="288" height="550" /> 
<img src="https://trello-attachments.s3.amazonaws.com/5ed622002651b51257a49f69/5ee255b2bd444e749960e9c1/dc072a070442487568aa7313850a56ad/screenshot-2020-06-26_00.56.00.136.png" width="288" height="550" /> 